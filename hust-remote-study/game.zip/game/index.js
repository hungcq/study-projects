const express = require('express')
var path = require('path');
const app = express()
const port = 3000
app.use('/loxolivestream', express.static(__dirname + '/loxolivestream'));
app.use('/resources', express.static(__dirname + '/resources'));

app.get('/', function(req, res) {
    res.sendFile(path.join(__dirname + '/game.html'));
});

app.listen(port, () => console.log(`Example app listening on port ${port}!`))